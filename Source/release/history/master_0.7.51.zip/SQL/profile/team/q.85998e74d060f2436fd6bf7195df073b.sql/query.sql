UPDATE RB_team
SET
	name = '{name}',
	description = '{description}'
WHERE id = {id};