SELECT *
FROM DEV_project
WHERE team_id = {tid};