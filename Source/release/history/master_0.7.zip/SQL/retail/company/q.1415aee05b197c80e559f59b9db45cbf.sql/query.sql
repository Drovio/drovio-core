INSERT IGNORE INTO RTL_company (id, name, description)
VALUES ({cid}, '{name}', '{desc}');