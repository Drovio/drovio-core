SELECT *
FROM RB_team
WHERE id = {tid};