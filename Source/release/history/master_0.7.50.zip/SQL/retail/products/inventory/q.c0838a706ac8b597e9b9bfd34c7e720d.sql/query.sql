SELECT *
FROM RTL_Cproduct
WHERE company_id = {cid} AND hierarchy_id = {hid};