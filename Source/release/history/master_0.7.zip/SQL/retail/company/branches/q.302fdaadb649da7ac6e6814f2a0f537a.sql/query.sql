SELECT *
FROM RTL_companyBranch
WHERE company_id = {cid};