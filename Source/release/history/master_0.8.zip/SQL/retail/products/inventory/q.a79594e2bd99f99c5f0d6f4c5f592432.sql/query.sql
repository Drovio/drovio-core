SET title = '{title}', description = '{desc}'
WHERE id = {hid};