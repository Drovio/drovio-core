INSERT INTO RTL_productPriceType (title, description, company_id)
VALUES ('{title}', '{description}', {cid});