SELECT *
FROM ID_team
WHERE id = {tid};