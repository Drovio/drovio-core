SELECT *
FROM MDL_moduleStatus