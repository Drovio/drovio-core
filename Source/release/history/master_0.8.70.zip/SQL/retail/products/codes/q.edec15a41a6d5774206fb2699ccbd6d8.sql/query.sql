DELETE FROM RTL_productCode
WHERE RTL_productCode.product_id = '{id}' AND RTL_productCode.type_id = {type};