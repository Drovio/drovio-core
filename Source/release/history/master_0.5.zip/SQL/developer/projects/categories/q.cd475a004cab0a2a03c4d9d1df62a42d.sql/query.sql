SELECT *
FROM DEV_projectType
WHERE private = 0