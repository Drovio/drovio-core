SELECT *
FROM RTL_paymentType;