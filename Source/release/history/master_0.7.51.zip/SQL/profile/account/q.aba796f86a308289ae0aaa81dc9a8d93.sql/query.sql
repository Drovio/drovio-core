SELECT *
FROM PLM_accountSession
WHERE PLM_accountSession.accountID = {aid} AND PLM_accountSession.id = {sid};