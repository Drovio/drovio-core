INSERT INTO VCS_projectCommitItem (commit_id, project_id, item_id)
VALUES ('{cid}', {pid}, '{item}');