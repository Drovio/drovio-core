DELETE FROM ID_teamAccount
WHERE team_id = {tid} AND account_id = {aid};