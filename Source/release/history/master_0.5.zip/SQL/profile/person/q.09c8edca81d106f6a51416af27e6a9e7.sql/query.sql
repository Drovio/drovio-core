SELECT * 
FROM RB_person
WHERE RB_person.id = {pid}