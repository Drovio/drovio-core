UPDATE RTL_company
SET name = '{name}', description = '{desc}'
WHERE id = {cid};