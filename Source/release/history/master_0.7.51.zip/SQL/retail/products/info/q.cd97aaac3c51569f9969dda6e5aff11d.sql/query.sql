SELECT *
FROM RTL_productInfoCategory
WHERE id = {cid};