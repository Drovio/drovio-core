SELECT *
FROM ID_accountSession
WHERE ID_accountSession.id = {sid} AND ID_accountSession.account_id = {aid};