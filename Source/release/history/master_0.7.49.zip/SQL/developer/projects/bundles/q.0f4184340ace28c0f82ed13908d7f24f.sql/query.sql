UPDATE BSS_bundle
SET
	online = {online}
WHERE id = {id};