SELECT COUNT(*) AS acc_count
FROM ID_account;