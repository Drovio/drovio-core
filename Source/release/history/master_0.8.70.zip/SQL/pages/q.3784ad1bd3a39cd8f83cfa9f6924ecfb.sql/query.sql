DELETE FROM PG_page
WHERE id = {id};