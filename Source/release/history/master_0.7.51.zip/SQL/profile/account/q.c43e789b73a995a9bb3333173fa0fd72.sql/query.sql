SELECT salt
FROM PLM_account
WHERE PLM_account.id = 1