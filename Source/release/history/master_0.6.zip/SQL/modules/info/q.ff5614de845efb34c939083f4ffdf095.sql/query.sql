SELECT *
FROM UNIT_moduleScope