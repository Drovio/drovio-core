SELECT *
FROM RTL_Cproduct
WHERE company_id = {cid} AND title LIKE '{title}';