SELECT *
FROM RTL_companyBranch
WHERE id = '{bid}' AND company_id = {cid};