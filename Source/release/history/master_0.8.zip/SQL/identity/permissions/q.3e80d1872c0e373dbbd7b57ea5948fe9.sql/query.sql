INSERT INTO ID_PM_group (name)
VALUES ('{gname}');