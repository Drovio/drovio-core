INSERT IGNORE INTO RTL_productInfoCategoryHierarchy (category_id, hierarchy_id)
VAUES ({cid}, {hid});