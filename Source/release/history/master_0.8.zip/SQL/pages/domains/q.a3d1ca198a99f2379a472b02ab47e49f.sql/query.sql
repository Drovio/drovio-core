DELETE FROM PG_domain
WHERE name = '{name}'