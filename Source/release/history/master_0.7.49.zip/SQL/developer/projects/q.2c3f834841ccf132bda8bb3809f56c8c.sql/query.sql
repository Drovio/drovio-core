INSERT INTO DEV_accountToProject (account_id, project_id)
VALUES ({aid}, {pid});