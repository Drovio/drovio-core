SELECT *
FROM RTL_storageUnit
WHERE id = '{suid}' AND company_id = {cid};