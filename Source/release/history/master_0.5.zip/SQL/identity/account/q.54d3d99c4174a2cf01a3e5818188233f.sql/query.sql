UPDATE ID_account
SET title = '{title}'
WHERE id = {aid};