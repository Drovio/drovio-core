SELECT *
FROM RTL_company
WHERe id = {id};