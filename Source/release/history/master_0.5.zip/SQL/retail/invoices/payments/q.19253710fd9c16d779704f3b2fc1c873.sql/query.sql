SELECT *
FROM RTL_invoicePayment
WHERE invoice_id = '{iid}';