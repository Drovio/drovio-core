SELECT *
FROM VCS_projectItem
WHERE project_id = {pid};