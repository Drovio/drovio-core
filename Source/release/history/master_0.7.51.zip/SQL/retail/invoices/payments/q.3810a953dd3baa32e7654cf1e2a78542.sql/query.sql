DELETE FROM RTL_invoicePayment
WHERE id = '{id}' AND invoice_id = '{iid}';