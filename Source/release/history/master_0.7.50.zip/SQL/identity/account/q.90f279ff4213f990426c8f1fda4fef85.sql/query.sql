UPDATE ID_account
SET reset = '{new_reset}'
WHERE id = '{aid}';