DELETE
FROM RB_invitation
WHERE email = '{email}' AND context = '{context}' AND type = {type};