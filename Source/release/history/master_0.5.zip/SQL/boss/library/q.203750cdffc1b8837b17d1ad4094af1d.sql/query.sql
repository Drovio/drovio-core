INSERT IGNORE INTO BSS_app_purchase (team_id, application_id, version, time_created, trial)
VALUES ({tid}, {pid}, '{version}', {time}, {trial});