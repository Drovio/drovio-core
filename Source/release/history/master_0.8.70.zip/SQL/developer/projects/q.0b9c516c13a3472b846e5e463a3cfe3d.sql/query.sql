INSERT INTO DEV_projectRelease (project_id, version, title, token, time_created, changelog)
VALUES ({pid}, '{version}', '{title}', '{token}', {time}, '{changelog}');