SELECT *
FROM BT_exception
WHERE project_id = {pid};