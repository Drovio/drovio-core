UPDATE RTL_storageUnit
SET title ='{title}', description = '{description}'
WHERE id = '{suid}' AND company_id = {cid};