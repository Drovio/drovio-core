SELECT *
FROM PG_pageFolder
ORDER BY PG_pageFolder.lft