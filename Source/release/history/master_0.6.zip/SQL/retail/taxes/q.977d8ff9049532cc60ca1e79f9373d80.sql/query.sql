SELECT *
FROM RTL_taxRate
WHERE RTL_taxRate.country_id = {cid};