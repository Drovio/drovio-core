DELETE FROM ID_account
WHERE id = {aid};