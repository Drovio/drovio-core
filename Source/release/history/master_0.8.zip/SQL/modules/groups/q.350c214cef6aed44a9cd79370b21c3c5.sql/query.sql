UPDATE MDL_moduleGroup
SET description = '{description}'
WHERE id = {gid};