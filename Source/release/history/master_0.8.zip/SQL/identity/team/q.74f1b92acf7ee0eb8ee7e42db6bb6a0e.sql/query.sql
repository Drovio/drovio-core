INSERT IGNORE INTO ID_teamAccount (team_id, account_id)
VALUES ({tid}, {aid});