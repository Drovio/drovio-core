UPDATE ID_team
SET
	name = '{name}',
	description = '{description}'
WHERE id = {tid};