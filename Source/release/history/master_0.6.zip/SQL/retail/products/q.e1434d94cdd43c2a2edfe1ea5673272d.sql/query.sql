DELETE FROM RTL_product
WHERE owner_company_id = {cid} AND id = '{pid}';