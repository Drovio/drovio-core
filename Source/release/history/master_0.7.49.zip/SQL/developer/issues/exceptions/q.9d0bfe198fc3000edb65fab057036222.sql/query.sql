INSERT INTO BT_exception (project_id, code, message, trace, server_info, extra_info, time_created)
VALUES ({project_id}, '{code}', '{message}', '{trace}', '{server_info}', '{extra_info}', {time});