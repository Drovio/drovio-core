UPDATE ID_person
SET
	firstname = '{firstname}',
	lastname = '{lastname}',
	middle_name = '{middle_name}'
WHERE id = {pid};