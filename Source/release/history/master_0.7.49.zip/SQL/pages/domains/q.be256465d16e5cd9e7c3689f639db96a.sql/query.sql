INSERT INTO PG_domain (name, path)
VALUES('{name}', '{path}');