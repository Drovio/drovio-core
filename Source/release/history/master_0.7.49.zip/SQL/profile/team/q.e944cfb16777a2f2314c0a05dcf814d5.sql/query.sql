SELECT *
FROM RB_team
WHERe id = {id};