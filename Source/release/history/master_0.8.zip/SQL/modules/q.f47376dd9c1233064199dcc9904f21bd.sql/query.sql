UPDATE MDL_module
SET 
	title = '{title}', 
	description = '{description}' 
WHERE id = {id};