SELECT *
FROM DEV_project
WHERE name = '{name}';