SELECT *
FROM ID_team
WHERE uname = '{uname}';