UPDATE UNIT_module
SET 
	title = '{title}', 
	description = '{description}' 
WHERE id = {id};