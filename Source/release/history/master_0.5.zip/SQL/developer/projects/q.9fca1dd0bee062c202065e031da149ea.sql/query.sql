UPDATE DEV_project
SET team_id = {tid}
WHERE id = {id};