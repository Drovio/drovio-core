INSERT IGNORE INTO ID_PM_accountGroup (account_id, group_id)
VALUES ({aid}, {gid});