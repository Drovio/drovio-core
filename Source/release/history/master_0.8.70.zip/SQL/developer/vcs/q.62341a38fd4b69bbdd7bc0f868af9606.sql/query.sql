SELECT *
FROM VCS_projectBranch
WHERE project_id = {pid};