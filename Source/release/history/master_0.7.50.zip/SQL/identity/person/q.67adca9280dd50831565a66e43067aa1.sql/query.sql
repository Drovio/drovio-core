DELETE FROM ID_person
WHERE ID_person.id = {pid};