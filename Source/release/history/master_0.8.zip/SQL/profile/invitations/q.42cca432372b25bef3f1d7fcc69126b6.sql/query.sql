INSERT INTO RB_invitation (email, context, type, group_id, token, time_created)
VALUES ('{email}', '{context}', {type}, {group_id}, '{token}', {time});