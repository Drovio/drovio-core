SELECT *
FROM DEV_project
WHERE id = {id};