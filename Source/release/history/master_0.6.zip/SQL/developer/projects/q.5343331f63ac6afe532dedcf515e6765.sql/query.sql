UPDATE DEV_project
SET name = '{name}'
WHERE id = {id};