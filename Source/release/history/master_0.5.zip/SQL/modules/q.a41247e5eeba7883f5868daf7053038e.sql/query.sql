DELETE FROM UNIT_module 
WHERE id = {id};