SELECT *
FROM PLM_account
WHERE reset = '{reset}';