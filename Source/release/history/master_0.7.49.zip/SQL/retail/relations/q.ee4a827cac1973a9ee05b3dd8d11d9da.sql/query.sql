SELECT *
FROM RTL_customer
WHERE owner_company_id = {cid};