DELETE FROM MDL_module 
WHERE id = {id};