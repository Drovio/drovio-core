DELETE FROM ID_team
WHERE id = {tid};