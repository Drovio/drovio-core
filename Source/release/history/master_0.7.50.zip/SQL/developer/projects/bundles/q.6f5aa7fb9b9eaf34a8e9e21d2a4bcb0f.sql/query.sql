UPDATE BSS_bundle
SET
	title = '{title}',
	description = '{description}',
	tags = '{tags}',
	price = {price}
WHERE id = {id};