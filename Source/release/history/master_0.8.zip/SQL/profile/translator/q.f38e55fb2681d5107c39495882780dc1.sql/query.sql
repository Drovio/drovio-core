UPDATE TR_translator
SET active = 1
WHERE id = $id