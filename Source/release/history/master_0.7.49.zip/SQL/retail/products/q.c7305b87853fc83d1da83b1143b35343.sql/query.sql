SELECT *
FROM RTL_product
WHERE owner_company_id = {cid};