DELETE FROM BSS_bundle_project
WHERE bundle_id = {bid} AND project_id = {pid};