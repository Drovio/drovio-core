SELECT *
FROM PG_pageFolder 
WHERE PG_pageFolder.id = {id}