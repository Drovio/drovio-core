DELETE FROM ID_PM_group
WHERE id = {gid} OR name = '{gname}';