SELECT salt
FROM PLM_accountSession
WHERE id = $sid and accountID = $aid;