SELECT *
FROM DEV_project
WHERE public = 1;