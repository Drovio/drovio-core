SELECT *
FROM RTL_invoiceType