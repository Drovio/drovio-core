SELECT *
FROM RTL_productCodeType