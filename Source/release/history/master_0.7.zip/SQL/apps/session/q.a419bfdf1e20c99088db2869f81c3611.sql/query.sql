DELETE
FROM AC_app_session 
WHERE uid = '{uid}' AND application_id = {application_id}