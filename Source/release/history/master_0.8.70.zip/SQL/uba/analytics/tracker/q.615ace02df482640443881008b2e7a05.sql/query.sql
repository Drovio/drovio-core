SELECT * 
FROM `event_detailed`