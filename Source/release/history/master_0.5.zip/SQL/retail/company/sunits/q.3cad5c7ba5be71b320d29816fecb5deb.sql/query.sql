SELECT *
FROM RTL_storageUnit
WHERE RTL_storageUnit.company_id = {cid};