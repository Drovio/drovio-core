SELECT *
FROM AC_app_session 
WHERE uid = '{uid}';