INSERT IGNORE INTO BSS_bundle_project (bundle_id, project_id)
VALUES ({bid}, {pid});