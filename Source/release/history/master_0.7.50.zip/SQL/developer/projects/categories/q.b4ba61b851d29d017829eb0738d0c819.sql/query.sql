SELECT *
FROM DEV_projectType