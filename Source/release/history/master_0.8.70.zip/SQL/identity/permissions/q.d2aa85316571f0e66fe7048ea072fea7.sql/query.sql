DELETE FROM ID_PM_accountGroup
WHERE account_id = {aid} AND group_id = {gid};