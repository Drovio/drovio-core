UPDATE TR_translator
SET active = 0
WHERE id = $id;