DELETE FROM RTL_invoiceProduct
WHERE invoice_id = '{iid}' AND product_id = '{pid}';