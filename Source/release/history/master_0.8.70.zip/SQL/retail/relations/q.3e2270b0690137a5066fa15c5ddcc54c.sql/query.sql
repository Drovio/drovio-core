INSERT INTO RTL_customer (person_id, owner_company_id)
VALUES ('{pid}', {cid});