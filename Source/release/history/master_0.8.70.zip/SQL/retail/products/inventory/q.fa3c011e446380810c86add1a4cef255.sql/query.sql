SELECT *
FROM RTL_productHierarchy
WHERE id = {hid};