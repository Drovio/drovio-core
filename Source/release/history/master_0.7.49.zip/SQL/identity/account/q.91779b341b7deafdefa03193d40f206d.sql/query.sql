SELECT *
FROM ID_account
WHERE reset = '{reset}';