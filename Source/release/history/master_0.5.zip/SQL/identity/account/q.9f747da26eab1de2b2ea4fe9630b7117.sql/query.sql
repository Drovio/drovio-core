UPDATE ID_account
SET username = '{username}'
WHERE id = {aid};