UPDATE RTL_Cproduct
SET global_product_id = {gid}
WHERE company_id = {cid} AND product_id = {pid};