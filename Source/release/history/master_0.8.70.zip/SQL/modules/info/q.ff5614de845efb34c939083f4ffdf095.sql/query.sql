SELECT *
FROM MDL_moduleScope