SELECT *
FROM UNIT_module 
WHERE group_id = {gid};