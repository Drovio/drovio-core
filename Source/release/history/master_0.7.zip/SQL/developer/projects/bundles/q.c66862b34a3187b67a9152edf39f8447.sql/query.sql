SELECT *
FROM BSS_bundle
WHERE id = {id};