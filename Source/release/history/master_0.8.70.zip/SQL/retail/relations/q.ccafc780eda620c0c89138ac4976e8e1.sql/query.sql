SELECT *
FROM RTL_customer
WHERE person_id = '{pid}' AND owner_company_id = {cid};