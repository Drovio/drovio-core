INSERT IGNORE INTO VCS_projectBranch (project_id, branch_name, parent)
VALUES ({pid}, '{name}', '{parent}');