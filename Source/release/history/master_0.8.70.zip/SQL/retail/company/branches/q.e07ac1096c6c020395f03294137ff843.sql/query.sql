UPDATE RTL_companyBranch
SET title ='{title}', address = '{address}'
WHERE id = '{bid}' AND company_id = {cid};