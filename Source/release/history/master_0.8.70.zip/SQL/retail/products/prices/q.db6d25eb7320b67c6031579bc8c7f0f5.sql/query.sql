DELETE FROM RTL_productPrice
WHERE product_id = '{pid}' AND type_id = {type};